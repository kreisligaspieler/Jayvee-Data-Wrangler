/* Workflow:
    1. Prompt the user for the URL pointing to a CSV file and the target database. ✓ // TODO Add zip and xls support
    2. Download the CSV file using Jayvee. ✓
    3. Attempt to determine the file encoding. ✓
    4. Identify the delimiter and enclosing used in the CSV file. ✓
    5. Check for headers or comments. ✓ 
    6. Retrieve column names from the CSV file. ✓
    7. Guess data types for each column. ✓
    8. Modify the data: 
        - Edit header names or data types ✓
        - Delete columns ✓
        - Specify constraints and valuetypes ✓
        - Transforms
    9. Handle some errors. ✓
    10. Run the .jv file and save the processed data into the specified database. ✓
    11. Format the .jv file


   Test csv: https://download-data.deutschebahn.com/static/datasets/haltestellen/D_Bahnhof_2020_alle.CSV
   https://geo.sv.rostock.de/download/opendata/museen/museen.csv
   https://geo.sv.rostock.de/download/opendata/bodenwertzonen_1999/bodenwertzonen_1999.csv
*/

import * as fs from "fs";
import * as path from "path";
import * as readInput from "./readInput";
import * as helpers from "./helpers";
import * as fileHelpers from "./generate_and_update_files";
import axios from "axios";
import * as readline from "readline";
import * as chardet from 'chardet';
import { exec } from 'child_process';

let projectPath: string;


/**
 * Creates a project folder at the specified location provided by the user.
 * Validates the location for writability and readability.
 */
async function createProjectFolder(): Promise<void> {
    let location: string;
    let projectName: string;
    let isValidLocation = false;

    // Keep asking the user for a valid location
    while (!isValidLocation) {
        location = await readInput.readFolder("Enter the directory to save the project (relative or absolute path). The project will be saved in a subfolder of this directory. Leave it blank to use the current folder: ");
        projectName = await readInput.readInput("Enter the project name. This will be used as the name for the project folder that will be created within your previously specified directory: ");
        // Create the project folder path
        projectPath = path.join(location, projectName);

        try {
            // Attempt to create the project folder
            fs.mkdirSync(projectPath);
            isValidLocation = true;
            console.log(`Project folder created at: ${projectPath}`);
        } catch (error) {
            if (error.code === 'EEXIST') {
                // Project name already exists
                const shouldOverride = await readInput.readInput(`Warning: Project name "${projectName}" already exists. Do you want to override the existing folder? (y/n): `);
                if (shouldOverride.toLowerCase() === 'y') {
                    // User chose to override, delete the existing folder and recreate
                    fs.rmSync(projectPath, { recursive: true, force: true });
                    fs.mkdirSync(projectPath);
                    console.log(`Project folder "${projectName}" overridden.`);
                    isValidLocation = true;
                } else {
                    // User chose not to override, ask for a different name and/ or location
                    console.log("Please provide a different project name and/or location.");
                }
            } else {
                // Other error, log the error message
                console.error(`Error: ${error.message}`);
            }
        }
    }
}

/**
 * Determine the value types for each column in a CSV file.
 * @param {string} filePath - The path to the CSV file.
 * @param {number} numCols - The number of columns that are in the CSV.
 * @param {string} delimiter - The delimiter used in the CSV file.
 * @param {string} enclosing - The enclosing used in the CSV file.
 * @param {number} skipLines - Number of lines to skip including the header
 * @returns {Promise<string[]>} A Promise that resolves with an array of value types for each column.
 */
async function determineColumnValueTypes(filePath: string, numCols: number, delimiter: string, enclosing: string, skipLines: number): Promise<Array<string>> {
    console.log("Detecting column value types. This process may take some time, depending on the size of the CSV file.");
    return new Promise<Array<string>>(async (resolve, reject) => {
        const readStream = fs.createReadStream(filePath, { encoding: 'utf-8' });
        const rl = readline.createInterface({ input: readStream, crlfDelay: Infinity });

        // Initialize an array to store the value types for each column
        const columnValueTypes: Array<string> = new Array(numCols).fill("");

        // Regular expressions for integer and decimal
        const numberRegex = /^[+-]?([0-9]*[,.])?[0-9]+([eE][+-]?\d+)?$/;
        let lineCounter = 0;
        rl.on('line', (line) => {
            // Ignore comments and header
            if (lineCounter == skipLines + 1) {
                // Get the values without enclosing
                const values = [];
                let current = "";
                let withinEnclosing = false;

                for (let i = 0; i < line.length; i++) {
                    const char = line[i];

                    if (char === enclosing) {
                        withinEnclosing = !withinEnclosing;
                    } else if (char === delimiter && !withinEnclosing) {
                        values.push(current);
                        current = "";
                    } else {
                        current += char;
                    }
                }

                values.push(current);
                // Counter to detect if all collumns are assigned with text -> stop scanning new lines, cause nothing would change
                let cnt = 0;
                // Compare the detected value types to the existing ones and update if needed
                values.forEach((value, index) => {
                    // Attempt to determine the value type
                    // Skip if text was already assigned
                    value=value.trim().replace(/\s{2,}/g, ' ');
                    if (columnValueTypes[index] != 'text') {
                        // Check if the integer column contains empy values -> datatype text
                        if (value == '') {
                            columnValueTypes[index] = "text";
                            cnt++;
                            console.log(`Warning: Detected empty cells, which are currently only supported by the text value type, so 'text' was assigned to the ${index}. column.`);
                            // Check if all columns are text columns
                            if (cnt == numCols - 1) {
                                rl.removeAllListeners('line');
                                return;
                            }
                        } else if (value.toLowerCase() == "true" || value.toLowerCase() == "false") {
                            if (columnValueTypes[index] == "integer" || columnValueTypes[index] == "decimal") {
                                columnValueTypes[index] = "text";
                                cnt++;
                                // Check if all columns are text columns
                                if (cnt == numCols - 1) {
                                    rl.removeAllListeners('line');
                                    return;
                                }
                            } else {
                                columnValueTypes[index] = "boolean";
                            }
                        } else if (numberRegex.test(value)) { //intger   
                            const decimal = Number.parseFloat(value.replace(',', '.'));
                            const integer = Math.trunc(decimal);

                            if (decimal == integer) {
                                if (columnValueTypes[index] == "boolean") {
                                    columnValueTypes[index] = "text";
                                    cnt++;
                                    // Check if all columns are text columns
                                    if (cnt == numCols - 1) {
                                        rl.removeAllListeners('line');
                                        return;
                                    }
                                } else if (columnValueTypes[index] != "decimal") {
                                    columnValueTypes[index] = "integer";
                                }
                            } else { //decimal
                                if (columnValueTypes[index] == "boolean") {
                                    columnValueTypes[index] = "text";
                                    cnt++;
                                    // Check if all columns are text columns
                                    if (cnt == numCols - 1) {
                                        rl.removeAllListeners('line');
                                        return;
                                    }
                                } else {
                                    columnValueTypes[index] = "decimal";
                                }
                            }
                        } else {
                            columnValueTypes[index] = "text";
                            cnt++;
                            // Check if all columns are text columns
                            if (cnt == numCols - 1) {
                                rl.removeAllListeners('line');
                                return;
                            }
                        }
                    } else {
                        cnt++;
                        // Check if all columns are text columns
                        if (cnt == numCols - 1) {
                            rl.removeAllListeners('line');
                            return;
                        }
                    }
                });
            } else {
                lineCounter++;
            }
        });

        rl.on('close', () => {
            resolve(columnValueTypes);
        });

        rl.on('error', (error) => {
            reject(error);
        });
    });
}



/**
 * Interprets a CSV file (semi) automaticly and creates the Jayvee pipeline.
 * @param {string} filePath - The path of the file to be interpreted. Must be an absolute or relative path to the file.
 * @param {string} fileName - The name of the csv file. //TODO change if zip support is implemented
 */
async function interpretCSV(filePath: string, fileName: string): Promise<void> {  // TODO subselection
    // Get the encoding and create TextFileInterpreter
    const encoding = await detectCSVEncoding(filePath);
    fileHelpers.appendToFile(projectPath, "pipeline.jv",
        `block TextFileInterpreter oftype TextFileInterpreter {encoding: "${encoding}";}`);
    // Find out how many lines are to skip, assuming we have a header
    let commentLines = await detectComments(filePath, encoding);
    // Remove comments at the beginning of a file
    fileHelpers.appendToFile(projectPath, "pipeline.jv",
        `block RangeSelector oftype TextRangeSelector {lineFrom: ${commentLines + 1};}`);
    // Find out delimiter and enclosing to create a CSVInterpreter
    const delimiter = await identifyCSVDelimiter(filePath, encoding, commentLines + 1);
    const enclosing = await identifyCSVEnclosing(filePath, encoding, delimiter, commentLines + 1);
    // ? Enclosing Escape
    let escape = "'";
    if (enclosing == "'") {
        escape = "";
    }
    fileHelpers.appendToFile(projectPath, "pipeline.jv",
        `block CSVInterpreter oftype CSVInterpreter {enclosing: ${escape}${enclosing}${escape};delimiter: "${delimiter}";}`);
    // Create placeholder for removing cols
    fileHelpers.appendToFile(projectPath, "pipeline.jv",
        `block ColumnDeleter oftype ColumnDeleter {delete: [];}`);
    // ? TODO Removing rows in UI        
    // Print the csv
    await helpers.printCSV(filePath, commentLines);
    // Check if the csv has a header
    let header = await getHeader(filePath, encoding, delimiter, commentLines + 1);
    const lenHeader = header.length;
    if (header[0] == null) {
        // Assign default header names col1, col2, col3, etc.
        header = Array.from({ length: lenHeader }, (_, index) => `col${index + 1}`);
    }
    // Identify the column to remove
    let headerMapping = helpers.createHeaderLetterMapping(header);
    let removedColumns = 0;
    let valueTypes = await determineColumnValueTypes(filePath, lenHeader, delimiter, enclosing, commentLines);
    // Check the header for duplicates and rename them
    if (await helpers.renameDuplicates(header)) {
        console.log("Identified duplicate header descriptions; automatically added literals to ensure uniqueness.");
    }
    console.log("Detected the following header and value types: ");
    for (let i = 0; i < header.length; i++) {
        console.log(`${header[i]}: ${valueTypes[i]}`);
    }
    // ? TODO Removing rows in UI        
    let options = ["Edit header names", "Edit value types", "Delete columns",
        "Define a custom constraint. This constraint can later be used to specify a value type. Please ensure to follow these steps in the specified order: (4) -> (5) -> (2).",
        "Define a custom valuetype. It can later be applied on a column. Custom valuetypes are used to remove unwanted database entries.",
        "Define transforms to specify the transformation of individual values. For example, you can multiply each value by 2.",
        "Apply transform on each value of a column.",
        "View the header",
        "I do not want to change anything"];
    let userInput = await readInput.chooseOption(`Do you want to edit the table?`, options);

    // Can be edited in the loop
    let allowedValuetypes = ["text", "integer", "decimal", "boolean"];
    let constraints: string[][] = [];
    let transforms: string[][] = [];
    while (userInput != options.length) {
        if (userInput == 1) {// Edit header
            const options = header.concat(["Return to previous menu"]);
            let optionChoosen = await readInput.chooseOption(`Which header name do you want to edit?`, options);
            if (optionChoosen < options.length) {
                header[optionChoosen - 1] = await readInput.readInput(`Please enter the new name: `);
                console.log(`Header changed succesfully. New header and value types:`);
                for (let i = 0; i < header.length; i++) {
                    console.log(`${header[i]}: ${valueTypes[i]}`);
                }
            }
        } else if (userInput == 2) { // Edit value types
            let optionChoosen = await readInput.chooseOption(`Select a column to edit its value type:`, header);
            if (optionChoosen < options.length) {
                valueTypes[optionChoosen - 1] = allowedValuetypes[await readInput.chooseOption(`Please choose between the following options:`, allowedValuetypes) - 1];
                console.log(`Data type of "${header[optionChoosen - 1]}" changed succesfully. New header and value types:`);
                for (let i = 0; i < header.length; i++) {
                    console.log(`${header[i]}: ${valueTypes[i]}`);
                }
            }
        } else if (userInput == 3) { // Remove columns
            const options = header.concat(["Return to previous menu"]);
            let indexToRemove = await readInput.chooseOption(`Which column do you want to remove?`, options);
            if (indexToRemove < options.length) {
                let columIdentifyer = headerMapping[indexToRemove - 1 + removedColumns];
                removedColumns++;
                console.log(columIdentifyer);
                fileHelpers.insertIntoFile(projectPath, "pipeline.jv", "block ColumnDeleter oftype ColumnDeleter {delete: [", "]", `column ${columIdentifyer},`);
                header.splice(indexToRemove - 1, 1);
                console.log(`Column removed succesfully. New header and value types:`);
                for (let i = 0; i < header.length; i++) {
                    console.log(`${header[i]}: ${valueTypes[i]}`);
                }
            }
        } else if (userInput == 4) {// Custom constraints
            let options = ["Allowlist [Compatible ValueType: text] (Limits the values to a defined a set of allowed values. All values in the list are valid.)",
                "Denylist [Compatible ValueType: text](Defines a set of forbidden values. All values in the list are considered invalid.)",
                "Length [Compatible ValueType: text](Limits the length of a string with an upper and/or lower boundary. All values with a length within the given range are valid.)",
                "Range [Compatible ValueType: decimal, integer](Limits the range of a number value with an upper and/or lower boundary which can be inclusive or exclusive. All values within the given range are considered valid.)",
                "Regex [Compatible ValueType: text](Limits the values complying with a regular expression (only recomendet for experienced users or programmers). All values that comply with the regex are considered valid.)",
                "No constraint (return to previous menu)"];
            let constraintTypes = ["AllowlistConstraint", "DenylistConstraint", "LenghtConstraint", "RangeConstraint", "RegexConstraint"];
            let constraint = await readInput.chooseOption(`Which kind of constraint do you want to create to append it to one or more columns?`, options);
            if (constraint != 6) {
                let constraintName = "";
                while (constraintName == "") {
                    constraintName = await readInput.readInput(`Please enter the name of the constraint: `);
                    //Invalid name
                    while (!/^[a-zA-Z]+$/.test(constraintName)) {
                        console.log(`Constraint names may only consist of letters 'a-z' and 'A-Z'. Please enter a different name.`);
                        constraintName = await readInput.readInput(`Please enter the name of the constraint: `);
                    }
                    //Constraint already exists
                    while (constraints.some(constraint => constraint[0] === constraintName)) {
                        console.log(`Constraint already exists. Please enter a different name.`);
                        constraintName = await readInput.readInput(`Please enter the name of the constraint: `);
                    }
                    constraints.push([constraintName, constraintTypes[constraint - 1]]);
                    if (constraint == 1) {//Allowlist: https://jvalue.github.io/jayvee/docs/user/constraint-types/AllowlistConstraint
                        let allowlistInput = await readInput.readInput(`Please insert the allowed values separated with a comma (e.g. ms, ns): `);
                        let allowlist = allowlistInput.includes(',') ?
                            allowlistInput.split(',').map(value => `"${value.trim()}"`).join(',') :
                            `"${allowlistInput.trim()}"`;
                        fileHelpers.appendToFile(projectPath, "pipeline.jv",
                            `constraint ${constraintName} oftype AllowlistConstraint { allowlist: [${allowlist}];}`)
                    } else if (constraint == 2) {//Denylist: https://jvalue.github.io/jayvee/docs/user/constraint-types/DenylistConstraint
                        let denylist = (await readInput.readInput(`Please insert the restricted values separated with a comma (e.g. "ms, ns")`)).includes(',') ?
                            (await readInput.readInput(`Please insert the restricted value: `)).trim() :
                            (await readInput.readInput(`Please insert the restricted value: `)).split(',').map(value => value.trim()).join(',');
                        fileHelpers.appendToFile(projectPath, "pipeline.jv",
                            `constraint ${constraintName} oftype DenylistConstraint { denylist: [${denylist}];}`);
                    } else if (constraint == 3) {//Length: https://jvalue.github.io/jayvee/docs/user/constraint-types/LengthConstraint
                        let userInput = await readInput.readInput(`Please insert the minimal length. If you leave it blank or insert an invalid value, 0 will be assigned: `);
                        let minLength = parseInt(userInput);
                        if (isNaN(minLength) || minLength < 0) {
                            minLength = 0;
                        }
                        userInput = await readInput.readInput(`Please insert the maximal length. If you leave it blank or insert an invalid value or if maxLength is smaller than minLength, 9007199254740991 will be assigned: `);
                        let maxLength = parseInt(userInput);
                        if (isNaN(maxLength) || maxLength < 0 || maxLength < minLength) {
                            maxLength = 9007199254740991;
                        }
                        fileHelpers.appendToFile(projectPath, "pipeline.jv",
                            `constraint ${constraintName} oftype LengthConstraint { minLength: ${minLength};maxLength: ${maxLength};}`);
                    } else if (constraint == 4) {//Range: https://jvalue.github.io/jayvee/docs/user/constraint-types/RangeConstraint
                        let userInput = await readInput.readInput(`Please insert the lower bound (inclusive). If you leave it blank or insert an invalid value, -9007199254740991 will be assigned: `);
                        let lowerBound = parseInt(userInput);
                        if (isNaN(lowerBound)) {
                            lowerBound = -9007199254740991;
                        }
                        userInput = await readInput.readInput(`Please insert the upper bound (inclusive). If you leave it blank or insert an invalid value or if maxLength is smaller than minLength, 9007199254740991 will be assigned: `);
                        let upperBound = parseInt(userInput);
                        if (isNaN(upperBound) || upperBound < lowerBound) {
                            upperBound = 9007199254740991;
                        }
                        fileHelpers.appendToFile(projectPath, "pipeline.jv",
                            `constraint ${constraintName} oftype RangeConstraint { lowerBound: ${lowerBound};upperBound: ${upperBound};}`);
                    } else if (constraint == 5) {//Regex: https://jvalue.github.io/jayvee/docs/user/constraint-types/RegexConstraint
                        let regex = await readInput.readInput(`Please insert the regex: `);
                        while (helpers.checkIfRegex(regex) == false) {//invalid regex
                            regex = await readInput.readInput(`Please insert a valid regex:`);
                        }
                        fileHelpers.appendToFile(projectPath, "pipeline.jv",
                            `constraint ${constraintName} oftype RegexConstraint { regex: ${regex};}`);

                    }
                }
            }
        } else if (userInput == 5) {// Custom valuetypes: https://jvalue.github.io/jayvee/docs/user/valuetypes/primitive-valuetypes
            if (constraints.length == 0) {
                console.log(`No constraints created. You have to create a constraint first.`);
            } else {
                let allowedBaseTypes = ["text", "integer", "decimal", "boolean"];
                let valueTypeName = await readInput.readInput(`Please enter a name for the new value type: `);
                //Invalid name
                while (!/^[a-zA-Z]+$/.test(valueTypeName)) {
                    console.log(`Value type names may only consist of letters 'a-z' and 'A-Z'. Please enter a different name.`);
                    valueTypeName = await readInput.readInput(`Please enter the name of the value type: `);
                }
                //Value type already exists
                while (allowedValuetypes.includes(valueTypeName)) {
                    console.log(`Value type already exists. Please enter a different name.`);
                    valueTypeName = await readInput.readInput(`Please enter the name of the value type: `);
                }
                let valueTypeBaseType = allowedBaseTypes[(await readInput.chooseOption(`Please choose the base type. Your base type will be altered with constraints in the next step.`, allowedBaseTypes)) - 1];
                let constraintsChoosen: string[] = [];
                // Choose constraint
                const chosenIndex = await readInput.chooseOption(`Please choose a previously created constraint.`, constraints.map((constraint, index) => `${constraint[0]} of type ${constraint[1]}`));
                constraintsChoosen.push(constraints[chosenIndex - 1][0]);
                while ((await readInput.readInput(`Do you want to add another constraint? Please enter 'y' or 'n': `)) == 'y') {
                    await readInput.chooseOption(`Please choose a previously created constraint.`, constraints.map((constraint, index) => `${constraint[0]} of type ${constraint[1]}`));
                    constraintsChoosen.push(constraints[chosenIndex - 1][0]);
                }
                fileHelpers.appendToFile(projectPath, "pipeline.jv",
                    `valuetype ${valueTypeName} oftype ${valueTypeBaseType} {
                    constraints: [${constraintsChoosen.join(',')}];}`);
                allowedValuetypes.push(valueTypeName);
            }
        } else if (userInput == 6) {// Create transforms 
            let transformName = "";
            let from: string[] = ["", ""];
            let to: string[] = ["", ""];
            let transform: string = "";
            while (transformName == "") {
                transformName = await readInput.readInput(`Please enter a name for the transform: `);
            }
            //Invalid name
            while (!/^[a-zA-Z]+$/.test(transformName)) {
                console.log(`Transform names may only consist of letters 'a-z' and 'A-Z'. Please enter a different name.`);
                transformName = await readInput.readInput(`Please enter a name for the transform: `);
            }
            //Transform already exists
            while (transforms.some(transform => transform[0][0] === transformName)) {
                console.log(`Transform already exists. Please enter a different name.`);
                transformName = await readInput.readInput(`Please enter the name of the transform: `);
            }
            console.log("A transform consists of an input and an output. Please choose names for both (e.g., Celsius for input, Fahrenheit for output) along with their corresponding data types.");
            from[0] = await readInput.readInput(`Input name: `);
            //Invalid name
            while (!/^[a-zA-Z]+$/.test(transformName)) {
                console.log(`Input names may from consist of letters 'a-z' and 'A-Z'. Please enter a different name.`);
                from[0] = await readInput.readInput(`Please enter a name for the transform: `);
            }
            from[1] = allowedValuetypes[await readInput.chooseOption(`Input value type: `, allowedValuetypes)];

            to[0] = await readInput.readInput(`Output name: `);
            //Invalid name
            while (!/^[a-zA-Z]+$/.test(to[0])) {
                console.log(`Output names may only consist of letters 'a-z' and 'A-Z'. Please enter a different name.`);
                to[0] = await readInput.readInput(`Please enter a name for the transform: `);
            }
            to[1] = allowedValuetypes[await readInput.chooseOption(`Input value type: `, allowedValuetypes)];

            transform = await readInput.readInput(`Please insert the transformation precisely (e.g. B:A*2). You can find a list of allowed operators here: 
            https://jvalue.github.io/jayvee/docs/user/expressions#list-of-operators and some examples here: 
            https://jvalue.github.io/jayvee/docs/user/transforms \n`);


            transforms.push([transformName, from[0], to[0]]);
            fileHelpers.appendToFile(projectPath, "pipeline.jv",
                `transform ${transformName}{
                    from ${from[0]} oftype ${from[1]};
                    to ${to[0]} oftype ${to[1]};
                    ${transform};
                }`);

            // https://jvalue.github.io/jayvee/docs/user/transforms/ 
            // https://jvalue.github.io/jayvee/docs/user/block-types/TableTransformer

        } else if (userInput == 7) { // Appyl transforms 
            if (transforms.length == 0) {
                console.log("No transform created. You need to create a transform first.")
            } else {
                let optionChoosen = await readInput.chooseOption(`Select a column to apply a transform:`, header);
                let inputColumn = "";
                let outputColumn = "";
                let transform = "";
                if (optionChoosen < options.length) {
                    inputColumn = header[optionChoosen - 1];
                    outputColumn = await readInput.readInput(`Please insert a name for the output column. If the name already exists in the header list, the column will be overridden, otherwise created: `);
                    //Invalid name
                    while (!/^[a-zA-Z]+$/.test(outputColumn[0])) {
                        console.log(`Output column names may only consist of letters 'a-z' and 'A-Z'. Please enter a different name.`);
                        outputColumn = await readInput.readInput(`Please enter a name for the transform: `);
                    }
                    const transformNames = transforms.map(transform => transform[0]);
                    optionChoosen = await readInput.chooseOption(`Select a previously created transform to apply a transform:`, transformNames);
                    transform = transforms[optionChoosen - 1][0];
                    fileHelpers.appendToFile(projectPath, "pipeline.jv",
                        `block ${transforms[optionChoosen - 1][1]}to${transforms[optionChoosen - 1][2]} oftype TableTransformer{
                    inputColumns: ['${inputColumn}'];
                    outputColumn: '${outputColumn}';
                    use: ${transform};
                }`);
                    fileHelpers.insertIntoFile(projectPath, "pipeline.jv", "->TableInterpreter", "-", `-> ${transforms[optionChoosen - 1][1]}to${transforms[optionChoosen - 1][2]}`);

                    console.log(`Transform applyed succesfully.`);

                }
            }
        } else if (userInput == 8) {// View the header
            for (let i = 0; i < header.length; i++) {
                console.log(`${header[i]}: ${valueTypes[i]}`);
            }
        }
        userInput = await readInput.chooseOption(`Do you want to edit anything else?`, options);
    }

    fileHelpers.appendToFile(projectPath, "pipeline.jv",
        `block TableInterpreter oftype TableInterpreter {
            header: false;
            columns: [`);
    for (let i = 0; i < header.length; i++) {
        if (i == header.length - 1) {
            fileHelpers.appendToFile(projectPath, "pipeline.jv",
                `"${header[i]}" oftype ${valueTypes[i]}];}`);
        } else {
            fileHelpers.appendToFile(projectPath, "pipeline.jv",
                `"${header[i]}" oftype ${valueTypes[i]},`);
        }
    }
    let databaseType = null;
    while (true) {
        databaseType = await readInput.readInput(`Which database type would you like to store the data in? Supported options are SQLite (1) and PostgreSQL (2). Please enter 1 or 2: `);
        if (databaseType == 1 || databaseType == 2) {
            break;
        }
        console.log("Invalid input.")
    }
    let host: string = "";
    let port: number = NaN;
    let username: string = "";
    let password: string = "";
    let database: string = "";
    let table: string = "";
    let databasePath: string = "";
    if (databaseType == 1) {
        while (true) {
            databasePath = await readInput.readInput(`Enter the folder where you want to save the database (absolute or relative path) or leave it blank to use the project folder: `);
            if (databasePath == '') {
                databasePath = projectPath;
            }
            database = await readInput.readInput(`Enter the database name without the file extension (wihout .sqlite) or leave it blank to use the name of the csv: `);
            if (database == "") {
                database = fileName;
            }
            table = await readInput.readInput(`Enter the name for the table or leave it blank to use the name of the csv: `);
            if (table == "") {
                table = fileName;
            }
            // Check if the database already exists
            const databaseExists = await helpers.checkIfDatabaseExists(path.join(databasePath, `${database}.sqlite`));

            if (databaseExists) {
                // Check if the table already exists in the database
                const tableExists = await helpers.checkIfTableExists(path.join(databasePath, `${database}.sqlite`), table);

                if (tableExists) {
                    // Ask the user if they want to override the table
                    let overrideTable = await readInput.readInput(`The table '${table}' already exists. Do you want to override it? (y/n): `);
                    while (overrideTable.toLowerCase() != 'y' && overrideTable.toLowerCase() != 'n') {
                        overrideTable = await readInput.readInput(`Invalid input. Type 'y' to make changes or 'n' to proceed with the detected headers and value types: `);
                    }
                    if (overrideTable.toLowerCase() == 'y') {
                        break;
                    } else {
                        console.log(`Please update following parameter.`);
                    }
                } else {
                    break; // Table doesn't exist
                }
            } else {
                break; // Database doesn't exist
            }
        }
        fileHelpers.appendToFile(projectPath, "pipeline.jv",
            `block Loader oftype SQLiteLoader {table: "${table}";
        file: "${databasePath}/${database}.sqlite";}`)
    } else { // TODO test PostgresSQL
        console.log("You've chosen to store the data in a PostgreSQL database. Please note that the PostgresSQL database must already exist. Please provide the necessary information. The data you type in will only be stored temporarily on your local machine.");
        while (host == "") {
            host = await readInput.readInput(`Host: `);
        }
        while (Number.isNaN(port)) {
            port = parseInt(await readInput.readInput(`Port: `));
        }
        while (username == "") {
            username = await readInput.readInput(`Username: `);
        }
        while (password == "") {
            password = await readInput.readInput(`Password: `);
        }
        while (database == "") {
            database = await readInput.readInput(`Database: `);
        }
        while (table == "") {
            table = await readInput.readInput(`Table: `);
        }
        fileHelpers.appendToFile(projectPath, "pipeline.jv",
            `block Loader oftype PostgresLoader {
                host: ${host};
                port: ${port};
                username: ${username};
                password: ${password};
                database: ${database};
                table: ${table};}`);
    }
}



/**
 * Detects and returns the first x lines with comments in a CSV file, and moves them in a text file. Also detects empty lines between comments.
 * @param {string} inputFilePath - The path to the input CSV file.
 * @param {string} encoding - The encoding of the CSV file.
 * @returns {Promise<number>} A Promise that resolves with the number of lines containing comments.
 **/
async function detectComments(inputFilePath: string, encoding: string): Promise<number> {
    return new Promise<number>((resolve, reject) => {
        const commentIndicators = ["#", "//", ";", "--", "/*", "!", "%", "["];

        const readStream = fs.createReadStream(inputFilePath, { encoding: encoding as BufferEncoding });
        const rl = readline.createInterface({ input: readStream, crlfDelay: Infinity });

        // File containing only the comments 
        // Extract directory path from input file path
        const outputDirectory = path.dirname(inputFilePath);

        // File containing only the comments
        const outputFileName = path.basename(inputFilePath, path.extname(inputFilePath)) + '_comments.txt';
        const outputFilePath = path.join(outputDirectory, outputFileName);
        const outputFileStream = fs.createWriteStream(outputFilePath, { encoding: encoding as BufferEncoding });
        let commentRows = 0;
        rl.on('line', (line) => {
            // Check if the line starts with any of the comment indicators -> write ith to a separate file
            if (commentIndicators.some((indicator) => line.trim().startsWith(indicator)) || line.trim() == '') {
                outputFileStream.write(line + '\n');
                commentRows++;
            } else {
                rl.close();
            }
        });

        rl.on('close', () => {
            outputFileStream.end();
            if (commentRows == 0) {
                fs.unlinkSync(outputFilePath); // Delete the empty comment file
            }
            resolve(commentRows);
        });

        rl.on('error', (error) => {
            reject(error);
        });
    });
}


/**
 * Checks if a CSV file has a header and returns it.
 * @param {string} filePath - The path to the CSV file.
 * @param {string} encoding - The encoding of the CSV file.
 * @param {string} delimiter - The delimiter used in the CSV file.
 * @param {numer} skipLines - Number of lines to skip (empty lines or comments).
 * @returns {Promise<string[]>} A Promise that resolves with an array containing the header if it exists; otherwise, it resolves with an empty array.
 */
// NOTE Different heuristics for checking for a potential header?
async function getHeader(filePath: string, encoding: string, delimiter: string, skipLines: number): Promise<string[]> {
    return new Promise<string[]>((resolve, reject) => {
        const readStream = fs.createReadStream(filePath, { encoding: encoding as BufferEncoding });
        const rl = readline.createInterface({ input: readStream, crlfDelay: Infinity });
        let lineNumber = 0;
        let potHeader: string = null;
        rl.on('line', (line) => {
            if (lineNumber == skipLines - 1) {
                potHeader = line;
                rl.close();
            }
            lineNumber++;
        });
        rl.on('close', async () => {
            // Split the first line using the provided delimiter
            const columns = potHeader.split(delimiter);
            // Check if all column contain non-numeric characters and resolve if all columns contain non-numeric characters          
            if (columns.every(column => isNaN(Number(column.trim())))) {
                resolve(columns);
            } else {
                resolve(new Array(columns.length).fill(null));
            }
            // Close the stream after processing the first line
            rl.close();
        });

        rl.on('error', (error) => {
            reject(error);
        });
    });
}


/**
 * Detects the encoding of a file using the chardet library.
 * @param {string} filePath - The path to the file.
 * @returns {Promise<string>} A Promise that resolves with the detected encoding.
 */
async function detectCSVEncoding(filePath: string): Promise<string> {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, async (err, data) => {
            if (err) {
                reject(err);
                return;
            }
            // Detect the encoding using chardet
            let encoding_detect = chardet.detect(data);
            // Format the encoidng for Jayvee
            let encoding = helpers.mapAndCheckEncoding(encoding_detect);
            if (encoding == null) {
                encoding = await readInput.readInput(`Encoding detected as ${encoding_detect} which is not supported yet. Supported encodings are 'utf8', 'ibm866', 'latin2', 'latin3', 'latin4', 'cyrillic', 'arabic', 'greek', 'hebrew', 'logical', 'latin6', and 'utf-16'. You could try one of the supported encodings by typing it in or terminate the program: `);
                encoding = helpers.mapAndCheckEncoding(encoding);
                while (encoding == null) {
                    encoding = await readInput.readInput("Your input is not a supported encoding! Please insert the encoding again. Supported encodings are 'utf8', 'ibm866', 'latin2', 'latin3', 'latin4', 'cyrillic', 'arabic', 'greek', 'hebrew', 'logical', 'latin6' and 'utf-16': ");
                    encoding = helpers.mapAndCheckEncoding(encoding);
                }
            }
            resolve(encoding);
        });
    });
}



/**
 * Reads the first ten lines of a CSV file to determine the delimiter.
 * @param {string} filePath - The path to the CSV file.
 * @param {string} encoding - The encoding of the CSV file
 * @param {number} skipLines - Number of lines to skip
 * @returns {Promise<string>} A Promise that resolves with the identified delimiter.
 */
async function identifyCSVDelimiter(filePath: string, encoding: string, skipLines: number): Promise<string> {
    return new Promise<string>(async (resolve, reject) => {
        // Open the file and read it line by line
        const readStream = fs.createReadStream(filePath, { encoding: encoding as BufferEncoding });
        const rl = readline.createInterface({ input: readStream, crlfDelay: Infinity });
        let sampleLine: string = null;
        let lineNumber = 0;
        rl.on('line', (line) => {
            if (lineNumber == skipLines - 1) {
                sampleLine = line;
                rl.close();
            }
            lineNumber++;
        });

        rl.on('close', async () => {
            const potentialDelimiter = [',', ';', '\t', '|', ':', ' '];
            let bestDelimiter: string | null;
            let maxDelimiterCount = 0;

            // Count the occurrences of each delimiter in the sample lines
            for (const delimiter of potentialDelimiter) {
                const delimiterCount = sampleLine.split(delimiter).length - 1;
                // Update the best delimiter if the count is higher
                if (delimiterCount > maxDelimiterCount) {
                    maxDelimiterCount = delimiterCount;
                    bestDelimiter = delimiter;
                }
            }
            // Resolve with the best delimiter if found, otherwise prompt the user
            if (bestDelimiter) {
                resolve(bestDelimiter);
            } else {
                // Prompt the user for the delimiter
                const userInput = await readInput.readInput("Unable to determine the delimiter. Please enter the delimiter or 'c' to abort the current execution of the Jayvee Data Wrangler: ");
                if (userInput.toLowerCase() === 'c') {
                    // Abort the program
                    console.log('Program aborted.');
                    reject(new Error('Program aborted by user.'));
                } else {
                    // Continue with the provided delimiter
                    const delimiter = userInput;
                    console.log(`Using user - provided delimiter: ${delimiter} `);
                    resolve(delimiter);
                }
            }
        });

        rl.on('error', (error) => {
            reject(error);
        });
    });
}



/**
 * Reads the first content line of a CSV file to determine the enclosing.
 * @param {string} filePath - The path to the CSV file.
 * @param {string} encoding - The file encoding.
 * @param {string} delimiter - The column delimiter.
 * @param {numer} skipLines - Number of lines to skip (empty lines or comments).
 * @returns {Promise<string>} A Promise that resolves with the identified enclosing.
 */
async function identifyCSVEnclosing(filePath: string, encoding: string, delimiter: string, skipLines: number): Promise<string> {//? TODO enclosing escape
    return new Promise<string>(async (resolve, reject) => {
        // Open the file and read it line by line
        const readStream = fs.createReadStream(filePath, { encoding: encoding as BufferEncoding });
        const rl = readline.createInterface({ input: readStream, crlfDelay: Infinity });

        const potentialEnclosingChars = ['"', "'"];
        let potentialEnclosing: string = "";
        let lineNumber = 0;
        rl.on('line', (line) => {
            if (lineNumber == skipLines) { // skips the header
                let charBefore="";
                for (const char of line) {
                    if (potentialEnclosingChars.includes(charBefore)&&char==delimiter) { //delimiter follows on enclosing
                        potentialEnclosing = charBefore;
                    }
                    charBefore=char;
                }
            }
            lineNumber++;
        });

        rl.on('close', async () => {
            if (potentialEnclosing == "" || potentialEnclosingChars.includes(potentialEnclosing)) {
                resolve(potentialEnclosing);
                return;
            }
            // If none of the potential enclosing characters are found, prompt the user
            let userInput: string;
            do {
                userInput = await readInput.readInput("Unable to determine the enclosing character. Please enter the enclosing character or 'c' to abort the current execution of the Jayvee Data Wrangler: ");

            } while (userInput.length !== 1 || potentialEnclosingChars.includes(userInput));

            if (userInput.toLowerCase() === 'c') {
                // Abort the program
                console.log('Program aborted.');
                reject(new Error('Program aborted by user.'));
            } else {
                // Continue with the provided enclosing;
                resolve(userInput);
            }
        });

        rl.on('error', (error) => {
            reject(error);
        });
    });
}





/**
* Downloads a CSV file by prompting the user for the file's URL.
* @param {string} downloadDirectory - The directory to download the CSV file to.
* @returns {Promise<[string, string]>} Path to the CSV file and the name of the CSV file.
*/
async function downloadCSV(): Promise<[string, string]> {
    try {
        // Get the URL from the user
        const url: string = (await readInput.readInput("Please insert the URL of the CSV file you want to import: ")).trim();
        if (!helpers.validateCSV(url)) {
            throw new Error("The URL you provided is not valid or the file is damaged. Please provide a different URL.");
        }
        let writeStream = null;
        let filePath = null;

        // Check if the url is available and the file is downloadable
        // ** TODO enable that timeout can be changed in UI within the settings
        try {
            const response = await axios({
                url,
                method: 'GET',
                responseType: 'stream',
                timeout: 60000, // one minute
            });

            // Check if the response status is not in the 200 range
            if (response.status < 200 || response.status >= 300) {
                throw new Error(`The URL you provided isn't available at the moment. Please try again later.`);
            }

            // Create a unique filename for the downloaded CSV file
            const fileName = `downloaded_file_${Date.now()}.csv`;
            filePath = path.join(projectPath, fileName);

            // Wirte the csv to the file system
            writeStream = fs.createWriteStream(filePath);
            response.data.pipe(writeStream);
        } catch (error) {
            throw new Error(`The URL you provided isn't available at the moment. Please try again later.`);
        }

        // Create the Jayvee file
        fileHelpers.appendToFile(projectPath, "pipeline.jv", `block Extractor oftype HttpExtractor {
            url: "${url}";}`);


        // Return the path and name to the downloaded CSV file
        return new Promise<[string, string]>((resolve, reject) => {
            writeStream.on('finish', () => {
                resolve([filePath, helpers.getFilenameFromURL(url)]);
            });

            writeStream.on('error', (error) => {
                reject(error);
            });
        });
    } catch (error) {
        console.error(error.message);
        throw error;
    }
}


async function main() {
    console.log("Welcome to the Jayvee Data Wrangler. This program automatically guides you through the process of loading data from a CSV into a database for further analysis. Throughout the process, you can specify various criteria to filter and preformat your data. If prompted to choose from options, please enter the corresponding number enclosed in brackets."); 
    await createProjectFolder();
    // Start the pipeline
    fileHelpers.writeToFile(projectPath, "pipeline.jv", "pipeline TestPipeline {Extractor -> TextFileInterpreter->RangeSelector->CSVInterpreter->ColumnDeleter->TableInterpreter->Loader;");
    //TODO lineBreak https://jvalue.github.io/jayvee/docs/user/block-types/TextFileInterpreter
    const [pathToCSV, filename] = await downloadCSV();
    await interpretCSV(pathToCSV, filename);
    // Close the pipelines
    fileHelpers.appendToFile(projectPath, "pipeline.jv", `}`);
    //await formatJayveeProject(projectPath, "pipeline.jv");
    // Execute the Jayvee pipeline
    const filePath = (path.join(projectPath, "pipeline.jv"));
    exec(`jv ${filePath}`, (error) => {
        if (error) {
            console.error(`Error executing Jayvee pipeline: ${error.message}`);
        }
    });
}

main();
