/* This file contains functions for reading user input
*/

import * as readline from 'readline';
import * as path from 'path';
import * as fs from 'fs';


/**
 * Reads user input asynchronously and returns a Promise with the input value.
 * @param {string} question - The prompt to ask the user.
 * @returns {Promise<string>} A Promise that resolves with the user's input.
 */
export async function readInput(question: string): Promise<string> {
    return new Promise<string>((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });

        rl.question(question, (answer) => {
            rl.close();
            // Check if the user entered something before resolving the Promise
            resolve(answer);
        });
    });
}

/**
 * Reads user input for a folder name with autocompletion asynchronously and returns a Promise with the input value.
 * @param {string} question - The prompt to ask the user.
 * @returns {Promise<string>} A Promise that resolves with the user's input.
 */
export function readFolder(question: string): Promise<string> { // TODO check
    return new Promise<string>((resolve) => {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            completer: (line: string) => {
                const dir = path.dirname(line);
                const prefix = path.basename(line);
                try {
                    const dirs = fs.readdirSync(dir);
                    return [dirs.filter((d) => d.startsWith(prefix)), prefix];
                } catch (error) {
                    return [[], prefix];
                }
            },
        });

        rl.question(question, (answer) => {
            rl.close();
            resolve(answer);
        });
    });
}

/**
 * Asks the user to choose between some options.
 * @param {string} message - The message to display to the user.
 * @param {string[]} options - A list of options the user can choose from.
 * @returns {Promise<number>}  A Promise that resolves with the number of the option chosen by the user.
 */
export async function chooseOption(message: string, options: string[]): Promise<number> {
    return new Promise<number>(async (resolve) => {
        let userInput: string = "";
        do {
            // Display the message and options to the user
            console.log(message);
            for (let i = 0; i < options.length; i++) {
                console.log(`(${i + 1}) ${options[i]}`);
            }

            // Get user input
            userInput = await readInput(``);
            // Validate user input
            if (Number.isNaN(parseInt(userInput)) || parseInt(userInput) < 1 || parseInt(userInput) > options.length) {
                console.log("Invalid option. Please choose a number between 1 and " + options.length + ".");
            }
        } while (Number.isNaN(parseInt(userInput)) || parseInt(userInput) < 1 || parseInt(userInput) > options.length);

        // Return the chosen option
        resolve(parseInt(userInput));
    });
}