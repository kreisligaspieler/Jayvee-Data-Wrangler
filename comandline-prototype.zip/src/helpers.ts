/* This file contains useful helper functions. It includes all functions that do not directly affect the Jayvee Pipeline.*/
// TODO Check async and promises
import fs = require('fs');
import csv = require('csv-parser');
import axios from 'axios';


/**
 * Renames duplicates in an array by adding an underscore and a current number 
 * @param {string[]} arr - The array to be modified
 * @returns {Promise<boolean>} A promise that reolves with true if duplicates were found and renamed.
 */
export async function renameDuplicates(arr: string[]): Promise<boolean> {
    return new Promise<boolean>(async (resolve) => {

        const columnCount: { [key: string]: number } = {};
        const duplicateIndices: { [key: string]: number[] } = {};

        let duplicates = false;

        // Iterate through each value in the array
        for (let i = 0; i < arr.length; i++) {
            const value = arr[i];

            // If the value already exists in the count object, it's a duplicate
            if (columnCount.hasOwnProperty(value)) {
                duplicates = true;

                // If it's the first occurrence of this specific duplicate, rename it with _1
                if (duplicateIndices.hasOwnProperty(value)) {
                    const firstOccurrenceIndex = duplicateIndices[value][0];
                    arr[firstOccurrenceIndex] = `${value}_1`;
                    duplicateIndices[value] = [firstOccurrenceIndex, i]; // Update the array with the current index
                }

                // Increment the count for this value
                columnCount[value]++;

                // Rename the current duplicate value with an underscore and the current count
                arr[i] = `${value}_${columnCount[value]}`;

                // Add the current index to the list of occurrences for this duplicate
                duplicateIndices[value].push(i);
            } else {
                // If it's the first occurrence, initialize the count to 1
                columnCount[value] = 1;
                duplicateIndices[value] = [i]; // Initialize the array with the current index
            }
        }
        resolve(duplicates);
    });
}

/**
 * Map chardet encoding to Node.js encoding and check if it's supported by Jayvee.
 * @param {string} chardetEncoding - The encoding detected by chardet.
 * @returns {string} The corresponding Node.js encoding.
 */
export function mapAndCheckEncoding(chardetEncoding: string): string {
    //format it for Jayvee
    chardetEncoding = chardetEncoding.replace(/-/g, '').toLowerCase();
    const supportedEncodings: { [key: string]: string | null } = {
        'utf8': 'utf8',
        'ibm866': 'ibm866',
        'iso88592': 'latin2',
        'iso88593': 'latin3',
        'iso88594': 'latin4',
        'iso88595': 'cyrillic',
        'iso88596': 'arabic',
        'iso88597': 'greek',
        'iso88598': 'hebrew',
        'logical': 'logical',
        'iso885910': 'latin6',
        'utf16': 'utf16',
        'latin2': 'latin2',
        'latin3': 'latin3',
        'latin4': 'latin4',
        'cyrillic': 'cyrillic',
        'arabic': 'arabic',
        'greek': 'greek',
        'hebrew': 'hebrew',
        'latin6': 'latin6'
    };
    return supportedEncodings[chardetEncoding] || null;
}

/**
 * Extracts the filename from a URL.
 * @param {string} url - The url of our file.
 * @returns {string | null} The filename extracted from the URL pointing to the file.
 */
export function getFilenameFromURL(url: string): string {
    const lastSlashIndex = url.lastIndexOf('/');
    const filenameWithExtension = url.substring(lastSlashIndex + 1); // Get the part after the last "/"
    const dotIndex = filenameWithExtension.indexOf('.');
    if (dotIndex === -1) {
        return filenameWithExtension;
    }
    return filenameWithExtension.substring(0, dotIndex); // Get the part before the file extension 
}

/**
 * Creates a mapping from column headers to Excel-style column letters.
 * @param {string[]} headers - An array of column headers.
 * @returns {Record<number, string>} - A mapping object where keys are then indices of the header values and values are Excel-style column letters.
 */
export function createHeaderLetterMapping(headers: string[]): Record<number, string> {
    const mapping: Record<number, string> = {};
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    for (let i = 0; i < headers.length; i++) {
        const letterIndex = Math.floor(i / letters.length);
        const letter = letterIndex === 0 ? letters[i] : letters[letterIndex - 1] + letters[i % letters.length];
        mapping[i] = letter;
    }

    return mapping;
}

/**
 * Checks if a given string is a valid regular expression.
 * @param {string} input - The string to check.
 * @returns {boolean} - True if the input string is a valid regular expression, false otherwise.
 */
export function checkIfRegex(input: string): boolean {
    try {
        new RegExp(input);
        return true;
    } catch (error) {
        return false;
    }
}

/**
 * Function to print CSV data after skipping the comments.
 * @param {string} filePath - The path to the CSV file.
 * @param {number} rowsToSkip - The number of rows to skip.
 */
export async function printCSV(filePath, rowsToSkip) {
    return new Promise<void>((resolve, reject) => {
        let lineCount = 0;
        let headers: any[];

        // Read the CSV file
        fs.createReadStream(filePath)
            .pipe(csv())
            .on('data', (row) => {
                lineCount++;

                // Skip rows until the desired number of rows to skip is reached
                if (lineCount <= rowsToSkip || lineCount - rowsToSkip > 10) {
                    return;
                }

                // Print headers if not already printed
                if (!headers) {
                    headers = Object.keys(row);
                    console.log(headers.join('\t'));
                }

                // Print each row with tab-separated values
                console.log(headers.map((header) => row[header]).join('\t'));
            })
            .on('end', () => {
                console.log('...\n');
                resolve();
            })
            .on('error', (error) => {
                reject(error);
            });
    });
}

/**
 * Checks if the database file exists.
 * @param {string} databasePath - The path to the database file.
 * @returns {boolean} True if the file exists, false otherwise.
 */
export async function checkIfDatabaseExists(databasePath: string): Promise<boolean> {
    try {
        // Check if the file exists
        fs.accessSync(databasePath, fs.constants.F_OK);
        return true;
    } catch (err) {
        return false;
    }
}


/**
 * Checks if a table exists in the database.
 * @param {string} databasePath - The path to the SQLite database file.
 * @param {string} tableName - The name of the table to check.
 * @returns {Promise<boolean>} - A Promise that resolves to true if the table exists, false otherwise.
 */
export async function checkIfTableExists(databasePath: string, tableName: string): Promise<boolean> {
    const sqlite3 = require('sqlite3');
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(databasePath);

        // Query to check if the table exists
        const query = `SELECT name FROM sqlite_master WHERE type='table' AND name='${tableName}';`;

        db.get(query, (err, row) => {
            if (err) {
                reject(err);
            } else {
                // Resolve with true if the table exists, false otherwise
                resolve(!!row);
            }
            // Close the database connection
            db.close();
        });
    });
}


/**
 * Check if a URL points to a valid CSV file.
 * @param {string} url - The URL to check.
 * @returns {Promise<string | null>} A Promise that resolves to an error message if the file is not valid CSV, or null if it is valid.
 */
export async function validateCSV(url: string): Promise<boolean> {
    try {
        // Fetch the content of the file
        const response = await axios.get(url);

        // Check if the content type is CSV
        const contentType = response.headers['content-type'];
        if (!contentType || !contentType.includes('text/csv')) {
            return false;
        }
        return true;
    } catch (error) {
        // Handle any network or fetch errors
        return false;
    }
}
